#!/bin/bash

gcc Santa.c -o Santa -lpthread

./Santa