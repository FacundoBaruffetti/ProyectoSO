#!/bin/bash

gcc Taller.c -o Taller -lpthread

./Taller